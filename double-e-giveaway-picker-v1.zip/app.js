let allRows = [];
let validEntries = [];
let currentWinner = null;

const $ = (id) => document.getElementById(id);

function parseCSV(text) {
  const rows = [];
  let row = [];
  let field = "";
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const next = text[i + 1];

    if (char === '"' && inQuotes && next === '"') {
      field += '"';
      i++;
    } else if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === "," && !inQuotes) {
      row.push(field.trim());
      field = "";
    } else if ((char === "\n" || char === "\r") && !inQuotes) {
      if (char === "\r" && next === "\n") i++;
      row.push(field.trim());
      if (row.some((value) => value !== "")) rows.push(row);
      row = [];
      field = "";
    } else {
      field += char;
    }
  }

  row.push(field.trim());
  if (row.some((value) => value !== "")) rows.push(row);
  return rows;
}

function normalizeHeader(value) {
  return value.toLowerCase().replace(/[^a-z0-9]/g, "");
}

function findColumn(headers, candidates) {
  const normalized = headers.map(normalizeHeader);
  for (const candidate of candidates) {
    const index = normalized.findIndex((header) => header.includes(candidate));
    if (index !== -1) return index;
  }
  return -1;
}

function secureRandomIndex(max) {
  if (max <= 0) throw new Error("No entries available.");
  const limit = Math.floor(0x100000000 / max) * max;
  const array = new Uint32Array(1);
  let value;
  do {
    crypto.getRandomValues(array);
    value = array[0];
  } while (value >= limit);
  return value % max;
}

function importEntries() {
  const file = $("csvFile").files[0];
  if (!file) {
    alert("Please choose a CSV file first.");
    return;
  }

  const reader = new FileReader();
  reader.onload = () => {
    try {
      const table = parseCSV(reader.result);
      if (table.length < 2) throw new Error("The CSV does not contain any data rows.");

      const headers = table[0];
      const nameIndex = findColumn(headers, ["name", "username", "user", "author", "profile"]);
      const commentIndex = findColumn(headers, ["comment", "message", "text", "content", "reply"]);
      const dateIndex = findColumn(headers, ["date", "time", "created", "timestamp"]);

      if (nameIndex === -1 || commentIndex === -1) {
        throw new Error("Could not find name and comment columns. Rename them to Name and Comment, then try again.");
      }

      allRows = table.slice(1).map((row, index) => ({
        id: index + 1,
        name: (row[nameIndex] || "").trim(),
        comment: (row[commentIndex] || "").trim(),
        date: dateIndex >= 0 ? (row[dateIndex] || "").trim() : ""
      }));

      applyRules();
    } catch (error) {
      alert(error.message);
    }
  };
  reader.onerror = () => alert("The CSV file could not be read.");
  reader.readAsText(file);
}

function applyRules() {
  const requireDone = $("requireDone").checked;
  const removeDuplicates = $("removeDuplicates").checked;
  const ignoreBlank = $("ignoreBlank").checked;

  let invalid = 0;
  let duplicates = 0;
  const seen = new Set();
  const result = [];

  for (const entry of allRows) {
    const blank = !entry.name || !entry.comment;
    const missingDone = requireDone && !/\bdone\b/i.test(entry.comment);

    if ((ignoreBlank && blank) || missingDone) {
      invalid++;
      continue;
    }

    const key = entry.name.toLowerCase().trim();
    if (removeDuplicates && seen.has(key)) {
      duplicates++;
      continue;
    }

    seen.add(key);
    result.push(entry);
  }

  validEntries = result;
  $("totalCount").textContent = allRows.length;
  $("duplicateCount").textContent = duplicates;
  $("invalidCount").textContent = invalid;
  $("validCount").textContent = validEntries.length;
  $("statsSection").classList.remove("hidden");
  renderEntries();
  $("statsSection").scrollIntoView({ behavior: "smooth", block: "start" });
}

function renderEntries() {
  const query = $("searchInput").value.trim().toLowerCase();
  const filtered = validEntries.filter((entry) =>
    entry.name.toLowerCase().includes(query) ||
    entry.comment.toLowerCase().includes(query)
  );

  const list = $("entryList");
  if (!filtered.length) {
    list.innerHTML = '<p class="empty-state">No matching entries.</p>';
    return;
  }

  list.innerHTML = filtered.slice(0, 500).map((entry) => `
    <div class="entry">
      <strong>${escapeHtml(entry.name)}</strong>
      <p>${escapeHtml(entry.comment)}</p>
    </div>
  `).join("");

  if (filtered.length > 500) {
    list.insertAdjacentHTML("beforeend", `<p class="empty-state">Showing first 500 of ${filtered.length} entries.</p>`);
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[char]));
}

function startDraw() {
  if (!validEntries.length) {
    alert("There are no valid entries to draw from.");
    return;
  }

  $("drawSection").classList.remove("hidden");
  $("winnerCard").classList.add("hidden");
  $("countdown").classList.remove("hidden");
  $("shuffleName").classList.remove("hidden");
  $("countdown").textContent = "3";
  $("shuffleName").textContent = "Preparing draw...";

  let count = 3;
  const countdownTimer = setInterval(() => {
    count--;
    if (count > 0) {
      $("countdown").textContent = count;
    } else {
      clearInterval(countdownTimer);
      $("countdown").textContent = "GO";
      shuffleNames();
    }
  }, 900);
}

function shuffleNames() {
  let spins = 0;
  const totalSpins = 28;
  const timer = setInterval(() => {
    const randomEntry = validEntries[secureRandomIndex(validEntries.length)];
    $("shuffleName").textContent = randomEntry.name;
    spins++;

    if (spins >= totalSpins) {
      clearInterval(timer);
      revealWinner();
    }
  }, 90 + spins * 2);
}

function revealWinner() {
  currentWinner = validEntries[secureRandomIndex(validEntries.length)];
  $("countdown").classList.add("hidden");
  $("shuffleName").classList.add("hidden");
  $("winnerName").textContent = currentWinner.name;
  $("winnerComment").textContent = currentWinner.comment;
  $("winnerMeta").textContent = `Selected from ${validEntries.length} valid entries`;
  $("winnerCard").classList.remove("hidden");
  launchConfetti();
}

function launchConfetti() {
  const container = $("confetti");
  container.innerHTML = "";
  for (let i = 0; i < 110; i++) {
    const piece = document.createElement("span");
    piece.style.left = `${Math.random() * 100}%`;
    piece.style.background = ["#f4c84a", "#ffffff", "#e1a900", "#ffdd73"][Math.floor(Math.random() * 4)];
    piece.style.animationDuration = `${2.5 + Math.random() * 2.5}s`;
    piece.style.animationDelay = `${Math.random() * .8}s`;
    piece.style.setProperty("--drift", `${-100 + Math.random() * 200}px`);
    container.appendChild(piece);
  }
  setTimeout(() => container.innerHTML = "", 6000);
}

function saveWinner() {
  if (!currentWinner) return;
  const history = JSON.parse(localStorage.getItem("doubleEHistory") || "[]");
  history.unshift({
    giveaway: $("giveawayTitle").value.trim() || "Untitled giveaway",
    winner: currentWinner.name,
    comment: currentWinner.comment,
    entryCount: validEntries.length,
    savedAt: new Date().toISOString()
  });
  localStorage.setItem("doubleEHistory", JSON.stringify(history.slice(0, 50)));
  renderHistory();
  alert("Winner saved.");
}

function renderHistory() {
  const history = JSON.parse(localStorage.getItem("doubleEHistory") || "[]");
  const list = $("historyList");

  if (!history.length) {
    list.innerHTML = '<p class="empty-state">No saved winners yet.</p>';
    return;
  }

  list.innerHTML = history.map((item) => `
    <div class="history-item">
      <strong>${escapeHtml(item.giveaway)}</strong>
      <span>🏆 ${escapeHtml(item.winner)}</span>
      <small>${item.entryCount} valid entries · ${new Date(item.savedAt).toLocaleString()}</small>
    </div>
  `).join("");
}

function downloadValidCSV() {
  if (!validEntries.length) return;
  const lines = [
    ["Name", "Comment", "Date"],
    ...validEntries.map((entry) => [entry.name, entry.comment, entry.date])
  ].map((row) => row.map(csvEscape).join(","));

  const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "double-e-valid-entries.csv";
  link.click();
  URL.revokeObjectURL(link.href);
}

function csvEscape(value) {
  const text = String(value ?? "");
  return `"${text.replace(/"/g, '""')}"`;
}

$("importBtn").addEventListener("click", importEntries);
$("searchInput").addEventListener("input", renderEntries);
$("startDrawBtn").addEventListener("click", startDraw);
$("rerollBtn").addEventListener("click", startDraw);
$("saveWinnerBtn").addEventListener("click", saveWinner);
$("downloadBtn").addEventListener("click", downloadValidCSV);
$("closeDrawBtn").addEventListener("click", () => $("drawSection").classList.add("hidden"));
$("clearHistoryBtn").addEventListener("click", () => {
  if (confirm("Clear all saved giveaway history?")) {
    localStorage.removeItem("doubleEHistory");
    renderHistory();
  }
});

renderHistory();
