# Double E Giveaway Picker

A mobile-friendly giveaway winner picker that runs entirely in the browser.

## What it does

- Uploads Facebook comments from a CSV file
- Finds common name and comment column headings
- Filters comments that contain `DONE`
- Removes duplicate entrants
- Displays valid entries
- Selects a winner using the browser's cryptographically secure random generator
- Saves previous winners on the device
- Exports valid entries as a CSV

## Uploading to GitHub from an iPhone

1. Open your empty GitHub repository.
2. Tap **uploading an existing file**.
3. Unzip this project in the iPhone Files app.
4. Upload `index.html`, `styles.css`, `app.js`, `README.md`, and `sample-comments.csv`.
5. Scroll down and tap **Commit changes**.

## Putting it online with GitHub Pages

1. In the repository, open **Settings**.
2. Open **Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch **main** and folder **/(root)**.
5. Tap **Save**.
6. GitHub will create a public website address after a few minutes.

Note: A private repository may require a paid GitHub plan for GitHub Pages. You can either temporarily make the repository public, or deploy it through Vercel.

## CSV format

The app recognises common headings such as:

- Name, Username, User or Author
- Comment, Message, Text or Content
- Date, Time or Timestamp

Example:

```csv
Name,Comment,Date
John Smith,DONE,2026-08-04
Sarah Jones,Done please,2026-08-04
```

All information stays in the browser and is not uploaded to a server.
